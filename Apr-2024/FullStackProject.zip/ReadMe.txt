This is full stack project, includes web pages that store the inputs from user in database (MySQL),
where html, css and java script are used to make the pages, styling, and form validation.