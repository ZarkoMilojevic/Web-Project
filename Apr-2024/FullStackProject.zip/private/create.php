<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Create Page</title>
    <link rel="stylesheet" href="stylesheet/Style.css" />

<?php
/**
* Assignment 2
* Cinema Collection
* Group Number: 27
* Group Members: Amirreza Mirzaei, Albin Biju, Zarko Milojevic
* Professor: Hala Own
* Description: create.php will create the data and insert them into the Database.
 */


// Requiering the credentials.php and database.php
require_once('dbCredentials.php');
require_once('database.php');
// calling the header.php to be as header in the create.php
include "Header.php";

// Connect the database
$db = db_connect();

// recieving the data by POST method and setting conditions to insert the data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $movie_name = $_POST['movie_name'];
    $genre = $_POST['genre'];
    $description = $_POST['description'];
    $release_date = $_POST['release_date'];
    $added_by = $_POST['added_by'];
// Defining the query as a String
    $sql = "INSERT INTO movies (movie_name, genre, description, release_date, added_by) VALUES ('$movie_name', '$genre', '$description', '$release_date', '$added_by')";
    $result = mysqli_query($db, $sql);

    $id = mysqli_insert_id($db);
// directing to the show.php if the process was successful 
    header("Location: show.php?id= $id");

}else{
    // directing to the signup.php if the process was unsuccessful
    header("Location: signup.php");
}
?>
