<?php
/**
* Assignment 2
* Cinema Collection
* Group Number: 27
* Group Members: Amirreza Mirzaei, Albin Biju, Zarko Milojevic
* Professor: Hala Own
* Description: edit.php will edit the data and insert them into the Database.
 */
// requiring the dbCredentials.php and databse.php
require_once('dbCredentials.php');
require_once('database.php');

// connect to the database
$db = db_connect();

if(!isset($_GET['id'])) {
    header("Location: ../public/index.php");
}

$id = $_GET["id"];

$page_title = 'Edit Movie Information';

// Handle form values sent by create.php

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    //Accessing the infomation
  $movie_name = $_POST['movie_name']; 
  $genre= $_POST['genre'] ;
  $description= $_POST['description'] ;
  $release_date = $_POST['release_date'];
  $added_by= $_POST['added_by'] ;

  //update the information
  $sql = "UPDATE movies set movie_name= '$movie_name', genre= '$genre', description= '$description', release_date= '$release_date', added_by = '$added_by' where id = '$id' ";
  $result = mysqli_query($db, $sql);
  
  header("Location: ../public/index.php?id = $id");
}
// display the information
    else{
        $sql = "SELECT * FROM movies WHERE id = '$id' ";

        $result_set = mysqli_query($db, $sql);
        $result = mysqli_fetch_assoc($result_set);
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Edit Page</title>
    <link rel="stylesheet" href="stylesheet/Style.css" />

<style>
 input[type="text"] {  
  color: #333 !important; /* Set text color */
}
#buttonEdit {
  color: #333 !important; /* Set text color */
}
</style>
<?php include 'Header.php' ?>

<div id="content">

  <div class="page-edit">
    <h1>Edit Movie information</h1>
    <form form action="<?php echo 'edit.php?id=' . $result['id']; ?>"method="post">
      <dl>
        <dt> ID</dt>
        <dd><input type="text" id="editFont" name="id" value="<?php echo $result['id']; ?>" /></dd>
        </dd>
      </dl>
      <dl>
        <dt>Movie Name</dt>
        <dd><input type="text" id="editFont" name="movie_name" value="<?php echo $result['movie_name']; ?>" /></dd>
      </dl>
      <dl>
        <dt>Genre</dt>
        <dd><input type="text" id="editFont" name="genre" value="<?php echo $result['genre']; ?>" /></dd>

        </dd>
      </dl>
      <dl>
        <dt>Description</dt>
        
        <dd><input type="text" id="editFont" name="description" value="<?php echo $result['description']; ?>" /></dd>

        </dd>
      </dl>
      <dl>
        <dt>Release Date</dt>
        
        <dd><input type="text" id="editFont" name="release_date" value="<?php echo $result['release_date']; ?>" /></dd>

        </dd>
      </dl>
      
      <dl>
        <dt>Added By</dt>
        
        <dd><input type="text" id="editFont" name="added_by" value="<?php echo $result['added_by']; ?>" /></dd>

        </dd>
      </dl>
      
      <div id="operations">
        <input type="submit" id="buttonEdit" value="Edit Movie Information" />
      </div>
    </form>

  </div>

</div>

<?php include 'Footer.php'; ?>

