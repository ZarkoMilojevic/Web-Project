<?php
/**
* Assignment 2
* Cinema Collection
* Group Number: 27
* Group Members: Amirreza Mirzaei, Albin Biju, Zarko Milojevic
* Professor: Hala Own
* Description: show.php will show the added data.
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Page</title>
    <link rel="stylesheet" href="../public/stylesheet/Style.css" />
</head>
<body>


    <?php 
    // requiring the dbCredentials.php and database.php
require_once('dbCredentials.php');
require_once('database.php');
include "Header.php";

// connect to databse
$db = db_connect();

$id = $_GET['id'] ;

// query to show the added data
$sql = "SELECT * FROM movies WHERE id = '$id' ";

$result_set = mysqli_query($db, $sql);

$result = mysqli_fetch_assoc($result_set);

?>

<div id="content">

  <div class="Movie show">

  <h1> <?php echo $result['added_by'] ; ?> Added:</h1>

<div class="attributes">
  <dl>
    <dt>Movie Name</dt>
    <dd><?php echo $result['movie_name']; ?></dd>
  </dl>
      <dl>
        <dt>Genre</dt>
        <dd><?php echo $result['genre']; ?></dd>
      </dl>
      <dl>
        <dt>Description</dt>
        <dd><?php echo $result['description']; ?></dd>
      </dl>
      <dl>
    <dt>Release Year</dt>
    <dd><?php echo $result['release_date']; ?></dd>
     </dl>
     <dl>
    <dt>User</dt>
    <dd><?php echo $result['added_by']; ?></dd>
     </dl>
      <dl>
        
    </div>


  </div>

</div>

<?php include'Footer.php'; ?>
</body>
</html>