<?php
/**
* Assignment 2
* Cinema Collection
* Group Number: 27
* Group Members: Amirreza Mirzaei, Albin Biju, Zarko Milojevic
* Professor: Hala Own
* Description: footer.php contains the footer of all the pages.
*/
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
    <link rel="stylesheet" href="../public/stylesheet/Style.css" />
</head>
<body>
    
    <footer>
        <div class="footer">
          <p>&copy; 2024 Movie Collection. All rights reserved.</p>
        </div>
      </footer>

      
</body>
</html>