<?php
/**
* Assignment 2
* Cinema Collection
* Group Number: 27
* Group Members: Amirreza Mirzaei, Albin Biju, Zarko Milojevic
* Professor: Hala Own
* Description: This file contains constants that define the configuration 
 * parameters for connecting to the database. It includes 
 * definitions for the database server, username, password, 
 * and database name.
 */

 // defining the server, user, password, and database name
define("DB_SERVER", "localhost");
define("DB_USER", "appuser");
define("DB_PASS", "password");
define("DB_NAME", "cinema");

?>

