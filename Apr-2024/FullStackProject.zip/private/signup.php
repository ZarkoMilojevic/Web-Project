<?php
/**
* Assignment 2
* Cinema Collection
* Group Number: 27
* Group Members: Amirreza Mirzaei, Albin Biju, Zarko Milojevic
* Professor: Hala Own
* Description: signup.php will insert the new data into the Database.
 */
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Create Page</title>
    <link rel="stylesheet" href="../public/stylesheet/Style.css" />
    <link
      href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
      rel="stylesheet"/>
    <script src="../public/Scripts/validate.js" defer></script>
  </head>
  <body class="iandsbody">
    <div class="loginwrapper">
      <!-- onsubmit attribute of this form will apply some restrictions on the form validation -->
      <form action='create.php' method="POST" name="form" onsubmit="return validate();" >
        <h1>Add to the Collection</h1>

        <div class="input-box">
          <input type="text" id="movieName" placeholder="Movie Name" name="movie_name" />
        </div>

        <div class="input-box">
          <input type="text" placeholder="Genre" name="genre" id="genre" />
        </div>

        <div class="input-box">
          <input type="text" placeholder="Description" name="description" id="description" />
        </div>

        <div class="input-box">
          <input type="text" placeholder="Release Year" name="release_date" id="date" />
        </div>
        <div class="input-box">
          <input type="text" placeholder="Name" name="added_by" id="name" />
        </div>

        <button type="submit" class="btn" action="get" >Add</button>
        <button type="reset" class="reset" id="btnr">Reset</button>

        

        <div class="home-btn">
          <a href="../public/index.php" class="home-btn">Home Page</a>
        </div>
      </form>
        </div>

  </body>
</html>
