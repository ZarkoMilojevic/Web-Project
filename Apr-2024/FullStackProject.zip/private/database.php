<?php 
/**
* Assignment 2
* Cinema Collection
* Group Number: 27
* Group Members: Amirreza Mirzaei, Albin Biju, Zarko Milojevic
* Professor: Hala Own
* Description: databse.php will validate the connection of the database
 */

// calling the dbCredentials.php
require_once('dbCredentials.php');

// Connecting to the databse
function db_connect() {
$connection = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
return $connection;
}

// disconnect the database
function db_disconnect($connection) {
    if(isset($connection)) {
      mysqli_close($connection);
    }
  }

// connection confirmation and if it fails it will send an error massage
  function confirm_db_connect() {
    if(mysqli_connect_errno()) {
      $msg = "Database connection failed: ";
      $msg .= mysqli_connect_error();
      $msg .= " (" . mysqli_connect_errno() . ")";
      exit($msg);
    }
  }
// if the query is not successful
  function confirm_result_set($result_set) {
    if (!$result_set) {
    	exit("Database query failed.");
    }
  }

?>
