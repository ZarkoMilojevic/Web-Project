<?php
/**
* Assignment 2
* Cinema Collection
* Group Number: 27
* Group Members: Amirreza Mirzaei, Albin Biju, Zarko Milojevic
* Professor: Hala Own
* Description: Header.php contains the Header of all the pages create.
 */
?>
    <link rel="stylesheet" href="../public/stylesheet/Style.css" />
    <header>
        <div class="container">
        <h1 id="logo"><a href="../public/index.php" style="text-decoration: none;">Movie Collection</a></h1>

          <div class="nav-buttons">
            <a href="signup.php" class="signup-button">Add to Collection</a>
            <a href="../public/index.php" class="signup-button">Home Page</a>
          </div>
        </div>
      </header>






