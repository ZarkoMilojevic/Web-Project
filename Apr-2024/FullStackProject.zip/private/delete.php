<?php 
/**
* Assignment 2
* Cinema Collection
* Group Number: 27
* Group Members: Amirreza Mirzaei, Albin Biju, Zarko Milojevic
* Professor: Hala Own
* Description: delete.php will delete the data and update the data.
 */
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Page</title>
    <link rel="stylesheet" href="stylesheet/Style.css" />
    <style>
    #buttonDelete {
      color: #333 !important; /* Set text color */
    }
    </style>
</head>
<body>

<?php
// calling the dbCredentials.php and database.php
require_once('dbCredentials.php');
require_once('database.php');
include "Header.php";
// connecting to the database
$db = db_connect();

if(!isset($_GET['id'])) {

    header("Location: ../public/index.php");
  }
  $id = $_GET["id"];
// Deleting the data with using the POST method
  if($_SERVER['REQUEST_METHOD'] == 'POST') {

    // query as a String
    $sql = "DELETE FROM movies WHERE id ='$id'";
      $result = mysqli_query($db, $sql);
  // directing to the index.php if the delete is done
    header("Location: ../public/index.php");
  
  } 
  // if the deleting was not successful this part of code will run
  else 
  {

    $sql = "SELECT * FROM movies WHERE id= '$id' ";
      
    $result_set = mysqli_query($db, $sql);
      
      $result = mysqli_fetch_assoc($result_set);
      
  }
?>

<?php $page_title = 'Delete Movie'; ?>


<div id="content">
<!-- Delete Information and get the confirm from the user -->
  <div class="page delete">
    <h1>Delete Information</h1>
    <p>Are you sure you want to delete this Movie Information?</p>
    <p class="item"><?php echo $result['movie_name']; ?></p>
<!-- deleting process in the webpage using form and a button of the type of submit-->
    <form form action="<?php echo 'delete.php?id=' . $result['id']; ?>"  method="post">
      <div id="operations">
        <input type="submit" id="buttonDelete" name="commit" value="Delete Movie" />
      </div>
    </form>
  </div>

<!-- Calling the footer.php-->
  <?php include 'Footer.php'; ?>
</div>

</body>
</html>
