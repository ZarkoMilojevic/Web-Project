DROP DATABASE Cinema;
/**
* Assignment 2
* Cinema Collection
* Group Number: 27
* Group Members: Amirreza Mirzaei, Albin Biju, Zarko Milojevic
* Professor: Hala Own
* Description:  Creating the database and inserting some data to it Database.
 */
-- CREATING CINEMA DATABASE
CREATE DATABASE Cinema;
GRANT USAGE ON *.* TO 'appuser'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON Cinema.* TO 'appuser'@'localhost';
FLUSH PRIVILEGES;

USE Cinema;

--
-- Table 
--

CREATE TABLE IF NOT EXISTS movies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    movie_name VARCHAR(255) NOT NULL,
    genre VARCHAR(100),
    description TEXT,
    release_date YEAR,
    added_by VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=COALESCE((SELECT MAX(id) FROM movies), 0) + 1;



-- Inserting data into the movies table
INSERT INTO movies (id, movie_name, genre, description, release_date, added_by) VALUES 
(1, 'Oppenheimer', 'Biography/Drama', 'A biographical drama film about J. Robert Oppenheimer, the theoretical physicist who led the Manhattan Project during World War II.','2023', 'Albin0029'),
(2, 'Barbie', 'Animation/Family', 'An animated family movie based on the popular Barbie doll franchise.', '2023', 'Matin1221'),
(3, 'Dune', 'Science Fiction/Adventure', 'An epic science fiction adventure film based on the novel by Frank Herbert.', '2024', 'Zarko001009'),
(4, 'Poor Things', 'Drama/Fantasy', 'A fantasy drama film based on the novel by Alasdair Gray.', '2023', 'Amir8mi'),
(5, 'Godfather', 'Crime/Drama', 'A classic crime drama film directed by Francis Ford Coppola, based on the novel by Mario Puzo.', '1972', 'John1382');


