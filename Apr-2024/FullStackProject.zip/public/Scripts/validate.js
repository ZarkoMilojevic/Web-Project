/**
 * Assignment 2
 * Cinema Collection
 * Group Number: 27
 * Group Members: Amirreza Mirzaei, Albin Biju, Zarko Milojevic
 * Professor: Hala Own
 * Description: Java Script Code to validate form in the sign up page
 */

let movieInput = document.querySelector("#movieName");
// create paragraph to display the error Msg returented by vaildateEmail() function
// and assign this paragraph to the class warning to style the error MSg
let movieError = document.createElement("p");
movieError.setAttribute("class", "warning");
// append the created element to the div
document.querySelectorAll(".input-box")[0].append(movieError);
//--------------------------------------------------------------------
let genreInput = document.querySelector("#genre");
// create paragraph to display the error Msg returented by vaildateEmail() function
// and assign this paragraph to the class warning to style the error MSg
let genreError = document.createElement("p");
genreError.setAttribute("class", "warning");
// append the created element to the div
document.querySelectorAll(".input-box")[1].append(genreError);
//-----------------------------------------------------------------------
let descriptionInput = document.querySelector("#description");
// create paragraph to display the error Msg returented by vaildateEmail() function
// and assign this paragraph to the class warning to style the error MSg
let descriptionError = document.createElement("p");
descriptionError.setAttribute("class", "warning");
// append the created element to the div
document.querySelectorAll(".input-box")[2].append(descriptionError);
//----------------------------------------------------------------------

let dateInput = document.querySelector("#date");
//creating a paragraph to display the error massage
let dateError = document.createElement("p");
// declarng attributes in the created elements
dateError.setAttribute("class", "warning");
// append the created element to the div
document.querySelectorAll(".input-box")[3].append(dateError);

//---------------------------------------------------------------------

let nameInput = document.querySelector("#name");
//creating a paragraph to display the error massage
let nameError = document.createElement("p");
// declarng attributes in the created elements
nameError.setAttribute("class", "warning");
// append the created element to the div
document.querySelectorAll(".input-box")[4].append(nameError);

// declaring and initializing the error massages
let movieErrorMsg = "X Movie name should be non-empty";
let genreErrorMsg = "X Genre should be non-empty";
let descriptionErrorMsg = "X Description should be non-empty";
let dateErrorMsg = "X Please enter a year in format YYYY";
let nameErrorMsg = "X Name should contain one capital letter";
let defaultMsg = "";

// Function to validate movie name
function validateMovie() {
  let movie = movieInput.value;

  let regexp = /.+/;

  if (regexp.test(movie)) {
    error = defaultMsg;
  } else {
    error = movieErrorMsg;
  }
  return error;
}
// Function to validate Genre
function validateGenre() {
  let genre = genreInput.value;

  let regexp = /.+/;

  if (regexp.test(genre)) {
    error = defaultMsg;
  } else {
    error = genreErrorMsg;
  }
  return error;
}
// Function to validate description
function validateDescription() {
  let description = descriptionInput.value;

  let regexp = /.+/;

  if (regexp.test(description)) {
    error = defaultMsg;
  } else {
    error = descriptionErrorMsg;
  }
  return error;
}

// Function to validate Date
function validateDate() {
  let date = dateInput.value;
  let regexp = /^\d{4}$/;

  if (regexp.test(date)) {
    error = defaultMsg;
  } else {
    error = dateErrorMsg;
  }

  return error;
}

// Function to validate Name of the user
function validateName() {
  let name = nameInput.value;
  let regexp = /[A-Z]/;

  if (regexp.test(name)) {
    error = defaultMsg;
  } else {
    error = nameErrorMsg;
  }
  return error;
}

// Function to validate all the function in case if one of the functions fails.
function validate() {
  let valid = true;
  let movieValidation = validateMovie();
  if (movieValidation !== defaultMsg) {
    movieError.textContent = movieValidation;
    valid = false;
  }

  let genreValidation = validateGenre();
  if (genreValidation !== defaultMsg) {
    genreError.textContent = genreValidation;
    valid = false;
  }

  let descriptionValidation = validateDescription();
  if (descriptionValidation !== defaultMsg) {
    descriptionError.textContent = descriptionValidation;
    valid = false;
  }
  let DateValidation = validateDate();
  if (DateValidation !== defaultMsg) {
    dateError.textContent = DateValidation;
    valid = false;
  }
  let name = validateName();
  if (name !== defaultMsg) {
    nameError.textContent = name;
    valid = false;
  }
  return valid;
}

// Event Listener for movie name
movieInput.addEventListener("blur", function () {
  let x = validateMovie();
  if (x == defaultMsg) {
    movieError.textContent = defaultMsg;
  }
});

// Event Listener for Genre
genreInput.addEventListener("blur", function () {
  let x = validateGenre();
  if (x == defaultMsg) {
    genreError.textContent = defaultMsg;
  }
});

// Event Listener for description
descriptionInput.addEventListener("blur", function () {
  let x = validateDescription();
  if (x == defaultMsg) {
    descriptionError.textContent = defaultMsg;
  }
});

// Event Listener for date
dateInput.addEventListener("blur", function () {
  let x = validateDate();
  if (x == defaultMsg) {
    dateError.textContent = defaultMsg;
  }
});

// Event Listener for name of the user
nameInput.addEventListener("blur", function () {
  let x = validateName();
  if (x == defaultMsg) {
    nameError.textContent = defaultMsg;
  }
});

// adding functionality to reset button to make the error massages back to default massage.
function resetForm() {
  movieError.textContent = defaultMsg;
  genreError.textContent = defaultMsg;
  descriptionError.textContent = defaultMsg;
  dateError.textContent = defaultMsg;
  nameError.textContent = defaultMsg;
}
document.forms["form"].addEventListener("reset", resetForm);

let form = document.forms["form"];

// Add event listener for form submission
form.addEventListener("submit", function (event) {
  // Prevent default form submission
  event.preventDefault();

  // Validate form fields
  if (validate()) {
    // If all fields are valid, submit the form
    form.submit();
  } else {
    // If any field is invalid, do not submit the form
    console.log("Form submission cancelled due to validation errors.");
  }
});
