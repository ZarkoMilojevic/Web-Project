<?php 
/**
* Assignment 2
* Cinema Collection
* Group Number: 27
* Group Members: Amirreza Mirzaei, Albin Biju, Zarko Milojevic
* Professor: Hala Own
* Description: index.php is the main page of the project and contains the whole data from the database.
 */
// requiring the dbCredentials.php and database.php 
require_once('../private/dbCredentials.php');
require_once('../private/database.php');

//Connect the database
$db = db_connect();

$search = "";
$filter = "";

if(isset($_GET['search'])){
  $search = $_GET['search'];
}


if(isset($_GET['submitFilter'])){
  $filter = $_GET['filterSelect'];
}

// running a query for the search and/or filter Function
$sql = "SELECT * FROM movies WHERE movie_name LIKE '%$search%' AND release_date LIKE '%$filter%' ";
$result = $db->query($sql);

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Movie Collection</title>
    <link rel="stylesheet" href="stylesheet/Style.css" />
    <style>
 input[type="text"] {  
  color: #333 !important; /* Set text color */
}
select {
  color: #333 !important; /* Set text color */
}
</style>
  </head>
  <body>
 
  <header>
        <div class="container">
          <h1 id="logo"><a href="index.php" style="text-decoration: none;">Movie Collection</a></h1>

          <div class="search-bar">
    <form method="get" action="index.php">
      <!-- value of the search input will run the query and returns the matched results-->
        <input type="text" name="search" id="search-keyword" placeholder="Search Movie..." value="<?php echo $search; ?>" />
        <button type="submit" name="submit">Search</button>
    </form>

      <!-- value of the filter input will run the query and returns the matched results-->
      <div class="filterDiv">
        <form method="get" action="index.php">
          <label for="releaseYear" class="filterText">Choose by year</label>
          <select id="filter" name="filterSelect" size=1>
    <?php
    // Query to get distinct release years from the database
    $release_date_query = "SELECT DISTINCT SUBSTRING(release_date, 1, 4) AS release_year FROM movies ORDER BY release_year DESC";
    $release_date_result = $db->query($release_date_query);

    // Loop through the result and create options for the select element
    while ($row = $release_date_result->fetch_assoc()) {
        $year = $row['release_year'];
        $selected = ($filter == $year) ? "selected" : "";
        echo "<option value=\"$year\" style=\"color: black;\" $selected>$year</option>";
    }
    ?>
</select>

        </select>
        <button type="submit" name="submitFilter">Filter</button>
    </form>
          </div>
          <div class="nav-buttons">
            <a href="../private/signup.php" class="signup-button">Add to Collection</a>
          </div>
        </div>
      </header>

      <main>

      <div id="content">
  <div class="subjects listing">
    <h1>Movies</h1>



  	<table class="indexbody">
  	  <tr>
        <th>ID</th>
        <th>Movie Name</th>
        <th>Genre</th>
  	    <th>Description</th>
        <th>Release Year</th>
        <th>Added By</th>
  	    <th>&nbsp</th>
  	    <th>&nbsp</th>
        <th>&nbsp</th>
  	  </tr>

      <?php 
      // implementing a while loop to collect all the information from the database
      while($results = mysqli_fetch_assoc($result)) { ?>
        <tr>
          <td><?php echo $results['id']; ?></td>
          <td><?php echo $results['movie_name']; ?></td>
          <td><?php echo $results['genre'] ; ?></td>
    	    <td><?php echo $results['description']; ?></td>
          <td><?php echo $results['release_date']; ?></td>
          <td><?php echo $results['added_by']; ?></td>
          <?php // adding view, edit , and delete key to go to those pages
          ?>
          <td><a class="action" href="<?php echo"../private/show.php?id=" . $results['id']; ?>">View</a></td>
          <td><a class="action" href="<?php echo "../private/edit.php?id=" . $results['id']; ?>">Edit</a></td>
          <td><a class="action" href=<?php echo "../private/delete.php?id=" . $results['id']; ?>>Delete</a></td>
          
    	  </tr>
      <?php } ?>
  	</table>
</main>


    <?php
    // calling the footer.php to insert the footer
    include("../private/Footer.php"); ?>

  </body>
</html>
