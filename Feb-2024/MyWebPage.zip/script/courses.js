/*
Name: Zarko Milojevic
ID: 041113810
Due Date: 21 Feb 2024
Section: CST 8285 - 313
Activity: Assignment 1
Description: This is a java script for the third page - Courses, for a personal website
*/

// Function for searching course by keyword
document.getElementById("search-keyword").addEventListener("keyup", searchCourse);
function searchCourse() {
    // Declare variables
    let input, filter, table, tr, i, txtValue;
    input = document.getElementById("search-keyword");
    filter = input.value.toUpperCase();
    table = document.getElementById("courseTable");
    tr = table.getElementsByTagName("tr");
    // Loop through all table rows, and hide those who don't match the search query

    for (i = 1; i < tr.length; i++) {
        txtValue = tr[i].getElementsByTagName("td")[0].firstElementChild.children[1].textContent;
        //         if (td) {
        //             txtValue = td.textContent || td.innerText;
        level = tr[i].getElementsByTagName("td")[1].textContent;
        code = tr[i].getElementsByTagName("td")[2].textContent;
        detail = tr[i].getElementsByTagName("td")[3].textContent;
        if (txtValue.toUpperCase().indexOf(filter) > -1 || code.toUpperCase().indexOf(filter) > -1 || detail.toUpperCase().indexOf(filter) > -1) {
            tr[i].style.display = "";
        }
        else { tr[i].style.display = "none"; }
    }
}

// Function to display the course detail by filtering course level
document.getElementById("courseLevel").addEventListener("input", searchCourseLevel);
function searchCourseLevel() {
    //Declare Variables
    let dropdown, table, tr, td, filter, txtValue;
    dropdown = document.getElementById("courseLevel");
    table = document.getElementById("courseTable");
    tr = table.getElementsByTagName("tr");
    filter = dropdown.value.substring(dropdown.value.length - 1);

    if (filter == 1 || filter == 2) {
        for (i = 1; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[1];
            if (td) {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    } else {
        for (i = 1; i < tr.length; i++) {
            tr[i].style.display="table-row";
        }
    }
}